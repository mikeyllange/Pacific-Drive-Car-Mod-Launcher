@echo off
powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://github.com/mikeyllange/Pacific-Drive-Car-Mod-Launcher/archive/refs/heads/main.zip' -OutFile '%~dp0Pacific-Drive-Car-Mod-Launcher.zip'"

echo.
echo Download complete!
pause